# Tbe3ni Android 1.1

نسخة Android موجهة للهاتف، ومعها GitHub Actions باش يتبنى APK بلا PC محلي.

## كيفاش تخرج APK من الهاتف
1. رفع مجلد `Tbe3ni_Android` إلى GitHub repository جديد.
2. افتح تبويب **Actions**.
3. شغّل workflow: **Build Tbe3ni APK**.
4. منين يسالي، دخل للـrun ثم **Artifacts** ثم حمّل `Tbe3ni-debug-apk`.

## AI
من داخل التطبيق تقدر تحدد رابط الـBackend من الإعدادات. ما تحطش `OPENAI_API_KEY` داخل التطبيق؛ المفتاح خاصو يبقى فالسيرفر.

## ملاحظة
الـAPK الناتج من workflow هو Debug APK للتجربة. للنشر في Google Play خاصنا Release signing وAAB وPrivacy Policy وإعدادات النشر.
