# Tbe3ni Android v1.0

تطبيق Tbe3ni | تبعني — دليلك خطوة بخطوة.

## داخل الحزمة
- Android WebView app mobile-first.
- AI chat endpoint جاهز.
- قاعدة مصادر رسمية JSON.
- Favorites محفوظة محلياً.
- إمكانية تغيير Backend URL من داخل التطبيق.
- Backend Node/Express داخل مجلد `backend/`.

## تشغيل Backend
```bash
cd backend
cp .env.example .env
# ضع OPENAI_API_KEY في .env إذا أردت AI حقيقي
npm install
npm start
```

ثم في التطبيق ضع:
`http://10.0.2.2:3000/api` للمحاكي Android، أو IP الكمبيوتر داخل نفس Wi‑Fi للهاتف الحقيقي.

## بناء APK
افتح مجلد `Tbe3ni_Android` في Android Studio ثم Gradle Sync و Build APK.

> الـAPK النهائي يحتاج Android SDK/Gradle environment. هذه الحزمة هي المشروع الجاهز للبناء وليست APK مبنياً مسبقاً.
